package com.springrestapi.spring_rest_service.Spring_Element;


import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PatientElementService {

	@Autowired
	private PatientElementRepo patientElementRepo;

	public List<Element> getAllPatientObjects() {
		List<Element> patientObjects = new ArrayList<>();
		patientElementRepo.findAll().forEach(patientObjects::add);
		return patientObjects;
	}
	
	public Object getPatientObject(Long patientID) {
		return patientElementRepo.findById(patientID);
	}
}