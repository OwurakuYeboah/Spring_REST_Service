package com.springrestapi.spring_rest_service.Spring_Element;


import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

/*
 * CRUDRepository is a class from the SpringFramework. It has built in CRUD operations... more on this class here... 
 * 
 * https://docs.spring.io/spring-data/commons/docs/current/api/org/springframework/data/repository/CrudRepository.html
 * 
 * I believe the ANT (Add Node Tool) can be implemented by using this repository in some fashion. Please give this a "look-see"
 */

public interface PatientElementRepo extends CrudRepository<Element, Long> {
	//Element findByName(String firstName);
	Element findByPatientID(Long patientID);
}