package com.springrestapi.spring_rest_service.Spring_Element;



import java.util.List;
import java.util.Set;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.springrestapi.spring_rest_service.elementEntities.Appointments;
import com.springrestapi.spring_rest_service.elementEntities.Location;

@Entity
@Table(name = "Patients")
public class Element {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	@Column(name = "patientid")
	private Long patientID;
	@Column(name = "firstname")
	private String firstName;
	@Column(name = "lastname")
	private String lastName;
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "patientid", referencedColumnName = "locid")
    private Location location;
    
    @OneToMany(mappedBy="element")
    private List<Appointments> appointments;
    
	public Long getPatientID() {
		return patientID;
	}

	public String getFirstName() {
		return firstName;
	}
	
	public String getLastName() {
		return lastName;
	}
	
	public Location getLocation() {
		return location;	
	}
	
	public List<Appointments> getAppointments() {
		return appointments;
	}

	// Future Update: FIX THIS FOR UUID (UNIVERSAL UNIQUE ID)
	public void setPatientID(Long patientID) {
		this.patientID = patientID;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	public void setAppointments(List<Appointments> appointments) {
		this.appointments = appointments;
	}

	@Override
	public String toString() {
		String returnString = patientID + "\n" + firstName;
		return returnString;
	}
}