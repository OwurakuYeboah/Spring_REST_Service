package com.springrestapi.spring_rest_service;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

// Entry point of the program
@SpringBootApplication
public class SpringServices {

	public static void main(String[] args) {
		System.out.print("Spring Service Test");
		SpringApplication.run(SpringServices.class, args);
	}

}