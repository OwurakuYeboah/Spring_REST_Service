package com.springrestapi.spring_rest_service.elementEntities;


import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.springrestapi.spring_rest_service.Spring_Element.Element;

@Entity
@Table(name = "location")
public class Location {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	@Column(name = "locationid")
	private Long locationID;
	@Column(name = "city")
	private String city;
	@Column(name = "state")
	private String state;
	@Column(name = "locid")
	private Long locID;
	
	@OneToOne(mappedBy = "location")
    private Element element;

	public Long getLocationID() {
		return locationID;
	}

	public String getCity() {
		return city;
	}
	
	public String getState() {
		return state;
	}

	public Long getLocID() {
		return locID;
	}

	public void setLocationID(Long locationID) {
		this.locationID = locationID;
	}
	
	public void setCity(String city) {
		this.city = city;
	}

	public void setState(String state) {
		this.state = state;
	}

	public void setLocID(Long locID) {
		this.locID = locID;
	}
}